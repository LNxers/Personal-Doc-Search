"""Maigret data test functions"""

import pytest
from maigret.result import MaigretCheckStatus
from maigret.utils import is_country_tag


TOP_SITES_ALEXA_RANK_LIMIT = 50

KNOWN_SOCIAL_DOMAINS = [
    "facebook.com",
    "instagram.com",
    "twitter.com",
    "tiktok.com",
    "vk.com",
    "reddit.com",
    "pinterest.com",
    "snapchat.com",
    "linkedin.com",
    "tumblr.com",
    "threads.net",
    "bsky.app",
    "myspace.com",
    "weibo.com",
    "mastodon.social",
    "gab.com",
    "minds.com",
    "clubhouse.com",
]


@pytest.mark.slow
def test_tags_validity(default_db):
    unknown_tags = set()

    tags = default_db._tags

    for site in default_db.sites:
        for tag in filter(lambda x: not is_country_tag(x), site.tags):
            if tag not in tags:
                unknown_tags.add(tag)

    # make sure all tags are known
    # if you see "unchecked" tag error, please, do
    # maigret --db `pwd`/maigret/resources/data.json --self-check --tag unchecked --use-disabled-sites
    assert unknown_tags == set()


@pytest.mark.slow
def test_top_sites_have_category_tag(default_db):
    """Top sites by alexaRank must have at least one category tag (not just country codes)."""
    sites_ranked = sorted(
        [s for s in default_db.sites if s.alexa_rank],
        key=lambda s: s.alexa_rank,
    )[:TOP_SITES_ALEXA_RANK_LIMIT]

    missing_category = []
    for site in sites_ranked:
        category_tags = [t for t in site.tags if not is_country_tag(t)]
        if not category_tags:
            missing_category.append(f"{site.name} (rank {site.alexa_rank})")

    assert missing_category == [], (
        f"{len(missing_category)} top-{TOP_SITES_ALEXA_RANK_LIMIT} sites have no category tag: "
        + ", ".join(missing_category[:20])
    )


@pytest.mark.slow
def test_no_unused_tags_in_registry(default_db):
    """Every tag in the registry should be used by at least one site."""
    all_used_tags = set()
    for site in default_db.sites:
        for tag in site.tags:
            if not is_country_tag(tag):
                all_used_tags.add(tag)

    registered_tags = set(default_db._tags)
    unused = registered_tags - all_used_tags

    assert unused == set(), f"Tags registered but not used by any site: {unused}"


@pytest.mark.slow
def test_social_networks_have_social_tag(default_db):
    """Known social network domains must have the 'social' tag."""
    from urllib.parse import urlparse

    missing_social = []
    for site in default_db.sites:
        url = site.url_main or ""
        try:
            hostname = urlparse(url).hostname or ""
        except Exception:
            continue
        for domain in KNOWN_SOCIAL_DOMAINS:
            if hostname == domain or hostname.endswith("." + domain):
                if "social" not in site.tags:
                    missing_social.append(f"{site.name} ({domain})")
                break

    assert missing_social == [], (
        f"{len(missing_social)} known social networks missing 'social' tag: "
        + ", ".join(missing_social)
    )


def test_planetaexcel_does_not_pin_bot_user_agent(default_db):
    """Planetaexcel is filtered by an Anubis bot rule that serves an HTTP 200
    'Access Denied' page to the python-requests User-Agent, which a
    status_code check reads as a found account for every username (#3191).
    The check must rely on Maigret's default browser User-Agent instead."""
    site = default_db.sites_dict["Planetaexcel"]
    assert not (site.headers or {}).get("User-Agent")


def test_cgtrader_disabled_behind_aws_waf(default_db):
    """CGTrader answers every profile URL, real or not, with an AWS WAF
    challenge (HTTP 202, empty body, x-amzn-waf-action: challenge), which a
    status_code check reads as a found account (#3163)."""
    site = default_db.sites_dict["CGTrader"]
    assert site.disabled is True
    assert "aws_waf_js_challenge" in site.protection


def _officiating_status(default_db, body, http_status, username):
    from unittest.mock import Mock
    from maigret.checking import process_site_result

    site = default_db.sites_dict["officiating"]
    info = {
        "username": username,
        "parsing_enabled": False,
        "url_user": site.url.format(username=username),
    }
    out = process_site_result((body, http_status, None), Mock(), Mock(), info, site)
    return out["status"].status


def test_officiating_profile_url_follows_forum_migration(default_db):
    """The forum moved profiles from /members/<name>.html to /u/<name>; the old
    path now redirects for real accounts and answers a JSON 404 for the rest."""
    site = default_db.sites_dict["officiating"]
    assert site.url == "https://forum.officiating.com/u/{username}"


def test_officiating_missing_user_is_not_claimed(default_db):
    """A missing user gets an HTTP 404 JSON error with no HTML, so a body-marker
    check read it as a found account for every username (#3302)."""
    body = '{"errors":[{"status":"404","code":"not_found"}]}'
    assert (
        _officiating_status(default_db, body, 404, "zyiub6")
        == MaigretCheckStatus.AVAILABLE
    )


def test_officiating_existing_user_is_claimed(default_db):
    body = "<!doctype html><title>Rich - The Official Forum</title>"
    assert _officiating_status(default_db, body, 200, "rich") == MaigretCheckStatus.CLAIMED
